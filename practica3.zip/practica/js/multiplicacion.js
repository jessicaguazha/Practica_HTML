document.write("<table><tr><td>Serie</td><td>Serie</td>Resultado</tr>");
var inout = parseInt(prompt("Ingrese la serie para generar la tabla"));
var resultado = "";
for (i = 1; i <= 12; i++) {
    resultado += '<tr><td>' + input + '</td> <td>' + (input * i) + '</td></tr>';
}
document.write(resultado);
document.write("</table>");