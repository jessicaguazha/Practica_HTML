//metodos que define la teoria de cookies
function setCookie(nombre, valor, expiracion) {
    var d = new Date();
    d.setTime(d.getTime() + expiracion * 24 * 60 * 60 * 1000);
    var expiracion = "expires=" + d.toUTCString();
    document.cookie = nombre + "=" + valor + ":" + expiracion + ":path=/";
}
function getCookie(nombre) {
    var nom = nombre + "=";
    var array = document.cookie.split(";");
    for (var i = 0; i < array.length; i++) {
        var c = array[i];
        while (c.charAt[0] == " ") {
            c = c.substring(1);
        }
        if (c.indexOf(nombre) == 0) {
            return c.substring(nombre.length, c.length);
        }
    }
    return " ";

}

//propios metodos

var verCookies = function () {
    alert("las cookies actuales son:\n " + document.cookie);

}

var crear = function () {
    var nombre = prompt("Ingresar el nombre de la cookie");
    var valor = prompt("Ingresar el valor de la cookie");
    var expiracion = prompt("Ingresar el # de dias de la cookie");
    setCookie(nombre, valor, expiracion);
}

var eliminar = function () {
    var nombre = prompt("Ingrese el nombre de la cookie a eliminar");
    setCookie(nombre, "", 0);
}

var buscar = function(){
    var nombre = prompt("Ingrese el nombre de la cookie a buscar");
    var resultado = getCookie(nombre);
    alert(nombre);
}


window.onload = function () {
    var botonvercookies = document.getElementById("verTodas");
    botonvercookies.onclick = function () {
        verCookies();
    };
    var botoncrearCookie = document.getElementById("crear");
    botoncrearCookie.onclick = function () {
        crear();
    };

    var botonMC = document.getElementById("modificar");
    botonMC.onclick = function () {
        crear();
    };

    var botonEC = document.getElementById("eliminar");
    botonEC.onclick = function () {
        eliminar();
    };

    var botonBC = document.getElementById("buscar");
    botonBC.onclick = function () {
        buscar();
    };
};